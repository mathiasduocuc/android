package com.example.miregistro.ui.styles

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.example.miregistro.ui.theme.Blanco
import com.example.miregistro.ui.theme.Dimens
import com.example.miregistro.ui.theme.GrisDeshabilitado
import com.example.miregistro.ui.theme.Primario


object EstilosBoton {
    val forma: Shape = RoundedCornerShape(size = Dimens.radioBoton)
    val relleno = PaddingValues(horizontal = 20.dp, vertical = 12.dp)

    @Composable
    fun coloresPrincipales(): ButtonColors = ButtonDefaults.buttonColors(
        containerColor = Primario,
        contentColor = Blanco,
        disabledContainerColor = GrisDeshabilitado,
        disabledContentColor = Blanco
    )

    @Composable
    fun colorSegundario(): ButtonColors = ButtonDefaults.outlinedButtonColors(
        contentColor = MaterialTheme.colorScheme.primary

    )
    @Composable
    fun bordeSegundario(): BorderStroke = BorderStroke(
        width = Dimens.bordeBoton, color = MaterialTheme.colorScheme.primary
    )
    @Composable
    fun elevacion(): ButtonElevation = ButtonDefaults.buttonElevation(
        defaultElevation = Dimens.elevacionBoton,
        pressedElevation = 1.dp
    )
}

fun Modifier.estiloAltoBoton(): Modifier = this.height(Dimens.alturaBoton)