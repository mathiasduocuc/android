package com.example.miregistro.ui.theme

import androidx.compose.ui.unit.dp

object Dimens {
    //espaciados {margins/padding/gap}
    val espaciadoMini = 4.dp
    val espaciadoChico = 8.dp
    val espaciadoMedio = 16.dp
    val espaciadoGrabde = 24.dp
    val espaciadoPantalla = 20.dp

    //Botones
    val alturaBoton = 52.dp
    val radioBoton = 14.dp
    val bordeBoton = 2.dp
    val elevacionBoton = 4.dp
    //campos de texto
    val radioCampo = 12.dp

    //card
    val radioTarjeta = 20.dp
    val elevacionTarjeta = 2.dp

    //imagenes
    val altoBanner = 200.dp
    val altoPortada = 180.dp
    val tamanoAvatar = 120.dp
    val bordeAvatar = 4.dp
    val tamanoIcono = 20.dp

}